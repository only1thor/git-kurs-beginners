# En tittel

## Et avsnitt!
- Forklar høyre side ->
- Snakk om promten /\
- PS. TC, husk å introdusere deg!

## Avsnitt 2
Hvis dere lurte er dette skrevet i "Markdown".
Anbefaler sterkt å sjekke ut,
om dere ikke allerede har.

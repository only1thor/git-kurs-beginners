# En tittel

## Et avsnitt!
Her er det innsikt å hente, så følg med!
PS. TC, husk å introdusere deg!

## Avsnitt 2
Hvis dere lurte er dette skrevet i "Markdown".
Anbefaler sterkt å sjekke ut
om dere ikke allerede har.
